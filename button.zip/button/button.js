let myLead = []
const inputEl = document.getElementById("input-el")
const inputBtn = document.getElementById("input-btn")
const ulEl = document.getElementById("ul-el")
console.log(ulEl)

inputBtn.addEventListener("click", function() {
    myLead.push(inputEl.value)
    renderLeads()
})

function renderLeads(){
let listItems = ""
for (i=0; i < myLead.length; i++) {
    //listItems += "<li> <a target='_blank' href='" + myLead[i]"'>" + myLead[i] + "</a></li>"
      listItems += `
      <li> 
            <a target='_blank' href='${myLead[i]}'>
                ${myLead[i]}
            </a>
       </li>
       `
    //ulEl.innerHTML += "<li>" + myLead[i] + "</li>"
    //const li = document.createElement("li")
    //li.textContent = myLead[i]
    //ulEl.append()
}
ulEl.innerHTML = listItems
inputEl .value="";
}