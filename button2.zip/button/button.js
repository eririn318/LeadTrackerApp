/*import { initializeApp } from "https://www.gstatic.com/firebasejs/11.3.0/firebase-app.js"
import { getDatabase } from "https://www.gstatic.com/firebasejs/11.3.0/firebase-database.js"

const firebaseConfig = {
    databaseURL: process.env.DATABASE_URL
}

const app = initializeApp(firebaseConfig)
const database = getDatabase(app)

console.log(firebaseConfig.databaseURL)
*/

let myLead = []
const inputEl = document.getElementById("input-el")
const inputBtn = document.getElementById("input-btn")
const ulEl = document.getElementById("ul-el")
const tabBtn = document.getElementById("tab-btn")
//console.log(ulEl)
const deleteBtn = document.getElementById("delete-btn")
const leadsFromLocalStrage = JSON.parse(localStorage.getItem("myLead"))
console.log(leadsFromLocalStrage)

if (leadsFromLocalStrage) {
    myLead = leadsFromLocalStrage
    render(myLead)
}

tabBtn.addEventListener("click", function(){    
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
        myLead.push(tabs[0].url)
        localStorage.setItem("myLead", JSON.stringify(myLead) )
        render(myLead)
    })
})
function render(leads) {
    let listItems = ""
    for (let i = 0; i < leads.length; i++) {
        listItems += `
            <li>
                <a target='_blank' href='${leads[i]}'>
                    ${leads[i]}
                </a>
            </li>
        `
    }
    ulEl.innerHTML = listItems
}

     
inputBtn.addEventListener("click", function(){
        console.log("Button clicked!")
    })    

deleteBtn.addEventListener("dblclick", function() {
    localStorage.clear()
    myLead = []
    render(myLead)
})
inputBtn.addEventListener("click", function() {
    myLead.push(inputEl.value)
    inputEl.value = ""
    localStorage.setItem("myLead", JSON.stringify(myLead))
    render(myLead)
    console.log(localStorage.getItem("myLead"))
})

